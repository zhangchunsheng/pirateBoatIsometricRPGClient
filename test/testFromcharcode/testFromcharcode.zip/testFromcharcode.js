var canvas = document.createElement("canvas");
canvas.style.cssText="idtkscale:ScaleAspectFit;";  // CocoonJS extension
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

document.body.appendChild(canvas);

ctx = canvas.getContext("2d", {antialias : true });
ctx.fillText("test" , 500, 500);

ctx.fillStyle = '#00f'; // blue
ctx.fillRect(600, 600, 100, 100);

var msg = encode(1, "test", '{"uid":8}');
console.log("msg" + msg);

window.addEventListener("touchstart", function(e) {
	var msg = encode(1, "test", '{"uid":8}');
	console.log("msg" + msg);
	ctx.fillText("msg:" + msg , 500, 520);
	socket.send(msg);
}, false);

window.addEventListener("click", function(e) {
	var msg = encode(1, "test", '{"uid":8}');
	console.log("msg" + msg);
	ctx.fillText("msg:" + msg , 500, 520);
	socket.send(msg);
}, false);

var socket = io.connect("http://seaking.wozlla.com:3014");
this.socket.on('connect', function () {
	console.log('connected');
	ctx.fillText("connected" , 500, 500);
});
this.socket.on('message', function (data) {
	console.log(data);
});